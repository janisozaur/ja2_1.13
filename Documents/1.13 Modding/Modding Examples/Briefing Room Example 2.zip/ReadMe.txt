Briefing Room Mini Mod v.0.2

Mission 1 : Find The HeadQuarters and npc Art
- Open the Laptop -> Brefing Room -> Accept mission 1
- Go to the sector C9. Enter tactical and go to the HQ building. Mission 1 is automatic completed and visible is next mission.

Mission 2: Kill Jack
- Open the Laptop -> Brefing Room -> Accept mission 2
- Jack is in sector C13. Find him in the bar. Kill him.
- Go to the sector C9. Enter tactical and go to the HQ building. Mission 2 is automatic completed and visible is next mission.

Mission 3: Find Item
- Open the Laptop -> Brefing Room -> Accept mission 3
- The item is sector B13 (Mission03.png)
- Go to the sector C9. Enter tactical and go to the HQ building. Mission 3 is automatic completed and visible is next mission.
- The item is removed from the mercenary inventory automatically.

Mission 4: Rescue Lena
- Open the Laptop -> Brefing Room -> Accept mission 4
- Lena is sector C13 in the bar.
- Go to the sector C9. Enter tactical and go to the HQ building. Mission 5 is automatic completed and visible is next mission.
- Take LENA to the HQ building where the NPC ART is inside.

Mission 5: Sector D13
- Set to Laptop -> Brefing Room -> Accept mission 5
- Kill all enemies in the sector D13.
- Go to the sector C9. Enter tactical and go to the HQ building.

----
Laptop Briefing room pass code: SN5631
----
